import { redirect } from "next/navigation";

export default function ErrorsRedirect() {
  redirect("/compliance");
}
