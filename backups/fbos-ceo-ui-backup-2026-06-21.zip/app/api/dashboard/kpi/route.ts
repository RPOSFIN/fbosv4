import { apiError, apiSuccess, authorize } from "@/lib/rbac/api-auth";
import {
  getIntegrationStatuses,
  getIntegrationSummary,
} from "@/lib/integrations/status";
import { countTodayFollowups } from "@/lib/followups/fetch";
import { getAdminClient } from "@/lib/supabase/admin";

export async function GET() {
  const auth = await authorize("dashboard", "read");
  if ("error" in auth) return auth.error;

  const supabase = getAdminClient();
  if (!supabase) {
    return apiError("Database not configured", 503);
  }

  const tables = [
    "leads",
    "followups",
    "quotations",
    "clients",
    "jobs",
    "finance_import_queue",
    "clickup_tasks",
  ] as const;
  const counts: Record<string, number> = {};

  for (const table of tables) {
    const { count, error } = await supabase
      .from(table)
      .select("*", { count: "exact", head: true });

    if (error) {
      counts[table] = 0;
      continue;
    }
    counts[table] = count || 0;
  }

  const connectors = await getIntegrationStatuses();
  let followupsToday = 0;
  try {
    followupsToday = await countTodayFollowups(supabase);
  } catch {
    followupsToday = 0;
  }

  return apiSuccess({
    leads: counts.leads,
    followups: counts.followups,
    followupsToday,
    quotations: counts.quotations,
    clients: counts.clients,
    jobs: counts.jobs,
    financeQueue: counts.finance_import_queue,
    clickupTasks: counts.clickup_tasks,
    integrations: getIntegrationSummary(connectors),
  });
}
