export default function DashboardCard() { return <div>Card</div>; } 
